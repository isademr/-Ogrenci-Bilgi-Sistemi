﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OgrenciBilgiSistemi
{
    public class YuksekLisansOgrenci : LisansustuOgrenci
    {
       

        public YuksekLisansOgrenci(string lisansUniversiteAdi, string lisansBolumAdi) : base(lisansUniversiteAdi,lisansBolumAdi )
        {
           
        }


    }
}
