﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OgrenciBilgiSistemi
{
   public class DoktoraOgrenci : LisansustuOgrenci
    {

        public string YuksekLisansUniversiteAdi { get; set; }
        public string YuksekLisansBolumAdi { get; set; }
        
        public DoktoraOgrenci(string lisansUniversiteAdi, string lisansBolumAdi, string yuksekLisansUniversiteAdi, string yuksekLisansBolumAdi)
           : base(lisansUniversiteAdi, lisansBolumAdi)
        {

            
            this.YuksekLisansUniversiteAdi = yuksekLisansUniversiteAdi;
            this.YuksekLisansBolumAdi = yuksekLisansBolumAdi;

        }

    }
}
