﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OgrenciBilgiSistemi
{
    public abstract class Ogrenci
    {
        public int No { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string Bolum { get; set; }
        public List<Ders> AldigiDersler { get; set; }
       // public Ders [] AldigiDersler { get; set; }

        public Ogrenci() { }

        //public Ogrenci(int no, string ad, string soyad, string bolum, List<Ders> aldigiDersler)
        //{
        //    No = no;
        //    Ad = ad;
        //    Soyad = soyad;
        //    Bolum = bolum;
        //    AldigiDersler = aldigiDersler;
        //}

        public decimal KumulatifBasariNotuHesapla(List<Ders> AldigiDersler)
        {
            int notToplam = 0;
            int krediToplam = 0;
            foreach (var ders in AldigiDersler)
            {
                notToplam += ders.Kredisi * ders.DonemSonuPuani;
                krediToplam += ders.Kredisi;
            }
            return Convert.ToDecimal(Convert.ToDecimal(notToplam) /Convert.ToDecimal(krediToplam));
        }
    }
}
