﻿namespace OgrenciBilgiSistemi
{
    public class Ders
    {
        public string Kodu { get; set; }
        public string Adi { get; set; }
        public int Kredisi { get; set; }
        public int DonemSonuPuani { get; set; }

        public Ders(string kodu, string adi, int kredisi, int donemSonuPuani)
        {
            Kodu = kodu;
            Adi = adi;
            Kredisi = kredisi;
            DonemSonuPuani = donemSonuPuani;
        }
    }
}
