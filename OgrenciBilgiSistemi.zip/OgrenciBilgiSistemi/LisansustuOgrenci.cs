﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OgrenciBilgiSistemi
{
    public class LisansustuOgrenci : Ogrenci
    {
        public string LisansUniversiteAdi { get; set; }
        public string LisansBolumAdi { get; set; }

        public LisansustuOgrenci(string lisansUniversiteAdi, string lisansBolumAdi)
        {
            this.LisansUniversiteAdi = lisansUniversiteAdi;
            this.LisansBolumAdi = lisansBolumAdi;
        }
    }
}
