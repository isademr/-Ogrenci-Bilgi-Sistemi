﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OgrenciBilgiSistemi
{
    class LisansOgrenci : Ogrenci
    {
        public LisansOgrenci()
        {

        }
    }
}
